
// This is a placeholder - normally this would be scaffolded automatically.
using Microsoft.AspNetCore.Mvc;
using BariApp.Models;

namespace BariApp.Controllers
{
    public class DogsController : Controller
    {
        public IActionResult Index()
        {
            var dog = new Dog
            {
                Id = 1,
                Name = "Бари",
                Age = 14,
                Breed = "Чихуахуа",
                Country = "Уругвай",
                Description = "Най-големият авер!",
                PhotoUrl = "/images/bari.jpg"
            };

            return View(new List<Dog> { dog });
        }
    }
}
