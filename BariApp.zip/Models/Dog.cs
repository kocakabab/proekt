
namespace BariApp.Models
{
    public class Dog
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Breed { get; set; }
        public string Country { get; set; }
        public string Description { get; set; }
        public string PhotoUrl { get; set; }
    }
}
