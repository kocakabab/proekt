
using Microsoft.EntityFrameworkCore;
using BariPetSiteFull.Models;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options) { }

    public DbSet<Story> Stories { get; set; }
}
